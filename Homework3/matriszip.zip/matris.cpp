/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
#include <string>
using namespace std;

void printMat(int matrix[4][4]) {

    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            cout << matrix[i][j] << "\t ";
        }
        cout << endl;
        cout << endl;
    }
}



void subMat(int matrixA[4][4], int matrixB[4][4]) {
    int subMat[4][4] = { {0,0,0,0}, {0,0,0,0}, {0,0,0,0} , {0,0,0,0} };
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            subMat[i][j] = matrixA[i][j] - matrixB[i][j];
        }
    }
    printMat(subMat);
}

void sumMat(int matA[4][4], int matB[4][4]) {
    int sumMat[4][4] = { {0,0,0,0}, {0,0,0,0}, {0,0,0,0} , {0,0,0,0} };
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            sumMat[i][j] = matA[i][j] + matB[i][j];
        }
    }
    printMat(sumMat);
}

void mulMat(int matrixA[4][4], int matrixB[4][4]) {
    int mulMat[4][4] = { {0,0,0,0}, {0,0,0,0}, {0,0,0,0} , {0,0,0,0} };
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            mulMat[i][j] = 0;
            for (int k = 0; k < 4; k++) {
                mulMat[i][j] += (matrixA[i][k] * matrixB[k][j]);
            }
        }
    }
    printMat(mulMat);
}

int determinan(int matA[4][4]) {
    int det = 0;
    for (int i = 0; i < 4; i++) {
        det += (matA[0][i] * (matA[1][(i + 1) % 3] * matA[2][(i + 2) % 3] - matA[1][(i + 2) % 3] * matA[2][(i + 1) % 3]));
    }
    return det;
}

void taranahade(int matA[4][4]) {
    int tMat[4][4] = { {0,0,0,0}, {0,0,0,0}, {0,0,0,0} , {0,0,0,0} };
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            tMat[i][j] = matA[j][i];
        }
    }
    printMat(tMat);

}



int main() {
    int matrixA[4][4] = { {9, 8, 0 , 7},
                        {1, 1 , 1 , 1},
                        {8 , 8 , 98 , 11} ,
                        {2 , 3 , 8 ,3} };


    int matrixB[4][4] = { {8, 10, 65 , 2},
                        {2, 6 , 6 , 4},
                        {5 , 5 , 5 , 5} ,
                        {9 , 16 , 0 ,5}
    };

    cout << "matris A : " << endl;
    printMat(matrixA);

    cout << "matris B: " << endl;
    printMat(matrixB);

    cout << "sum : " << endl;
    sumMat(matrixA, matrixB);

    cout << "minus : " << endl;
    subMat(matrixA, matrixB);


    cout << "determinan :  " << endl;
    cout << determinan(matrixA) << endl;

    cout << "multiplication : " << endl;
    mulMat(matrixA, matrixB);

    cout << " taranahadeh :  " << endl;
    taranahade(matrixA);


    return 0;
}

